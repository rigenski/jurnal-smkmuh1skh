<table>
    <thead>
        <tr>
            <th><b>KELAS</b></th>
            <th><b>KODE MATA PELAJARAN</b></th>
            <th><b>NAMA MATA PELAJARAN</b></th>
            <th><b>USERNAME GURU</b></th>
            <th><b>NAMA GURU</b></th>
        </tr>
    </thead>
</table>
