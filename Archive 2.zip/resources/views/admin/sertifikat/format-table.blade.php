<table>
    <thead>
        <tr>
            <th><b>NIS</b></th>
            <th><b>NAMA</b></th>
            <th><b>KELAS</b></th>
            <th><b>PROGRAM KEAHLIAN</b></th>
            <th><b>PENUGASAN</b></th>
            <th><b>PREDIKAT</b></th>
            <th><b>DAFTAR KOMPETENSI</b></th>
            <th><b>CATATAN</b></th>
        </tr>
    </thead>
</table>
