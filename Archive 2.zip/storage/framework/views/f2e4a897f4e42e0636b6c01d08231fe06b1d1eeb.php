<table>
    <thead>
        <tr>
            <th><b>TAHUN PELAJARAN</b></th>
            <th><b>SEMESTER</b></th>
            <th><b>NIS</b></th>
            <th><b>NAMA</b></th>
            <th><b>KELAS</b></th>
            <th><b>GURU</b></th>
            <th><b>P1</b></th>
            <th><b>P2</b></th>
            <th><b>P3</b></th>
            <th><b>P4</b></th>
            <th><b>P5</b></th>
            <th><b>P6</b></th>
            <th><b>P7</b></th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $data_refleksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $count = 1; ?>
            <tr>
                <td><?php echo e($data->tahun_pelajaran); ?></td>
                <td><?php echo e($data->semester); ?></td>
                <td><?php echo e($data->nis); ?></td>
                <td><?php echo e($data->nama); ?></td>
                <td><?php echo e($data->kelas); ?></td>
                <td><?php echo e($data->guru); ?></td>
                <td><?php echo e($data->mata_pelajaran); ?></td>
                <td><?php echo e($data->pertanyaan1); ?></td>
                <td><?php echo e($data->pertanyaan2); ?></td>
                <td><?php echo e($data->pertanyaan3); ?></td>
                <td><?php echo e($data->pertanyaan4); ?></td>
                <td><?php echo e($data->pertanyaan5); ?></td>
                <td><?php echo e($data->pertanyaan6); ?></td>
                <td><?php echo e($data->pertanyaan7); ?></td>
            </tr>
            <?php $count++; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<table>
    <tbody>
        <tr>
            <td></td>
        </tr>
    </tbody>
</table>
<table>
    <tbody>
        <tr>
            <td colspan="16">INFORMASI</td>
        </tr>
        <tr>
            <td colspan="16">P1: Guru memulai dan mengakhiri pembelajaran tepat waktu ?</td>
        </tr>
        <tr>
            <td colspan="16">P2: Guru melaksanakan strategi pembelajaran dengan suasana interaktif, inspiratif,
                menyenangkan, menantang, memotivasi peserta didik untuk berpartisipasi aktif dan memberikan ruang yang
                cukup bagi prakarsa, kreativitas, kemandirian sesuai dengan bakat, minat, perkembangan fisik dan
                psikologis peserta didik ?</td>
        </tr>
        <tr>
            <td colspan="16">P3: Guru melaksanakan pembelajaran dengan memberikan keteladanan, pendampingan dan
                fasilitasi ?</td>
        </tr>
        <tr>
            <td colspan="16">P4: Tingkat kepuasan proses pembelajaran untuk mata pelajaran ini ?</td>
        </tr>
        <tr>
            <td colspan="16">P5: Tingkat kepuasan proses pembelajaran teori secara keseluruhan ?</td>
        </tr>
        <tr>
            <td colspan="16">P6: Tingkat kepuasan proses pembelajaran praktek secara keseluruhan ?</td>
        </tr>
        <tr>
            <td colspan="16">P7: Harapan dan masukkan peserta didik untuk kemajuan sekolah ?</td>
        </tr>
    </tbody>
</table>
<?php /**PATH /Applications/MAMP/htdocs/simaku/jurnal-smkmuh1skh/resources/views/admin/refleksi_siswa/table.blade.php ENDPATH**/ ?>