<table>
  <thead>
    <tr>
      <th><b>NAMA</b></th>
      <th><b>USERNAME</b></th>
      <th><b>PASSWORD</b></th>
    </tr>
  </thead>
</table><?php /**PATH /Applications/MAMP/htdocs/jurnal-gondang/resources/views/admin/guru/format-table.blade.php ENDPATH**/ ?>