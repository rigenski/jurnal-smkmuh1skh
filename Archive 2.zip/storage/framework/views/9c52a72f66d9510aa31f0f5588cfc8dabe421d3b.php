

<?php $__env->startSection('main'); ?>
<div class="container my-0 my-sm-5 px-0 px-sm-2">
    <div class="card m-0 bg-white shadow-md">
        <div class="card-header bg-success p-3 p-sm-4 py-4 py-sm-5">
            <div class="row my-4 my-md-4">
                <div class="col-2 col-lg-1 pr-1 pl-md-4">
                    <img src=" <?php echo e(asset('assets/img/logo-smk.png')); ?>" class="img-fluid">
                </div>
                <div class="col-10 col-lg-11  pl-3 pl-md-4">
                    <h6 id="form__desc" class="text-white">Semester Genap Tahun Pelajaran
                        2021/2022</h6>
                    <h1 id="form__title" class="text-white">E-Jurnal Mengajar Guru Bulan
                        <?php echo e($time->format('F')); ?> <?php echo e($time->format('Y')); ?></h1>
                </div>
            </div>
        </div>
        <div class="card-body p-3 p-sm-5">
            <div class="d-flex justify-content-between mt-4">
                <p class="h6 font-weight-light">Selamat datang, <span
                        class="font-weight-bold text-primary "><?php echo e(auth()->user()->name); ?></span>
                </p>
                <div class="d-flex">
                    <a href="#modalHistori" data-toggle="modal" class="h6 ">
                        <span class="font-weight-bold text-success border-bottom border-success mx-1">
                            Histori
                        </span>
                    </a>
                    <a href="<?php echo e(route('logout')); ?>" class="h6 ">
                        <span class="font-weight-bold text-danger border-bottom border-danger mx-1">
                            Logout
                        </span>
                    </a>

                </div>
            </div>
            <form action="<?php echo e(route('create')); ?> " method="post">
                <?php echo e(csrf_field()); ?>

                <div class="form-group my-4">
                    <label for="tanggal">1. Tanggal <span class="text-danger"><b>*</b></span></label>
                    <input type="text" class="form-control mt-2 datepicker <?php $__errorArgs = ['tanggal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        id="tanggal" name="tanggal" autocomplete="off" value="<?php echo e(old('tanggal')); ?>">
                    <small id="kompetensi_keahlian" class="form-text text-muted mt-2">Contoh Penulisan :
                        2004-05-15</small>
                    <?php $__errorArgs = ['tanggal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group my-4">
                    <label for="kelas">2. Kelas <span class="text-danger"><b>*</b></span></label>
                    <div class="form-check my-2">
                        <input class="form-check-input <?php $__errorArgs = ['kelas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="radio" name="kelas"
                            id="kelas1" value="X" ">
                                            <label class=" form-check-label" for="kelas1">
                        X
                        </label>
                    </div>
                    <div class="form-check my-2">
                        <input class="form-check-input <?php $__errorArgs = ['kelas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="radio" name="kelas"
                            id="kelas2" value="XI" " >
                                            <label class=" form-check-label" for="kelas2">
                        XI
                        </label>
                    </div>
                    <div class="form-check my-2">
                        <input class="form-check-input <?php $__errorArgs = ['kelas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="radio" name="kelas"
                            id="kelas3" value="XII" ">
                                            <label class=" form-check-label" for="kelas3">
                        XII
                        </label>
                    </div>
                    <?php $__errorArgs = ['kelas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group my-4">
                    <label for="kompetensi_keahlian">3. Kompetensi Keahlian/Paralel <span
                            class="text-danger"><b>*</b></span></label>
                    <input type="text" class="form-control mt-2 <?php $__errorArgs = ['kompetensi_keahlian'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        id="kompetensi_keahlian" name="kompetensi_keahlian" autocomplete="off"
                        value="<?php echo e(old('kompetensi_keahlian')); ?>">
                    <small id="kompetensi_keahlian" class="form-text text-muted mt-2">Contoh Penulisan : TKRO
                        1</small>
                    <?php $__errorArgs = ['kompetensi_keahlian'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group my-4">
                    <label for="jam_ke">4. Mengajar Jam Ke- <span class="text-danger"><b>*</b></span></label>
                    <input type="text" class="form-control mt-2 <?php $__errorArgs = ['jam_ke'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jam_ke"
                        name="jam_ke" autocomplete="off" value="<?php echo e(old('jam_ke')); ?>">
                    <small id="jam_ke" class="form-text text-muted mt-2">Contoh Penulisan : 1-2</small>
                    <?php $__errorArgs = ['jam_ke'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group my-4">
                    <label for="mata_pelajaran">5. Mata Pelajaran <span class="text-danger"><b>*</b></span></label>
                    <input type="text" class="form-control mt-2 <?php $__errorArgs = ['mata_pelajaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        id="mata_pelajaran" name="mata_pelajaran" autocomplete="off" value="<?php echo e(old('mata_pelajaran')); ?>">
                    <small id="mata_pelajaran" class="form-text text-muted mt-2">Contoh Penulisan : Bahasa
                        Indonesia</small>
                    <?php $__errorArgs = ['mata_pelajaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group my-4">
                    <label for="siswa_hadir">6. Jumlah Siswa yang Hadir <span
                            class="text-danger"><b>*</b></span></label>
                    <input type="text" class="form-control mt-2 <?php $__errorArgs = ['siswa_hadir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        id="siswa_hadir" name="siswa_hadir" autocomplete="off" value="<?php echo e(old('siswa_hadir')); ?>">
                    <small id="siswa_hadir" class="form-text text-muted mt-2">Contoh Penulisan : 35</small>
                    <?php $__errorArgs = ['siswa_hadir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group my-4">
                    <label for="siswa_tidak_hadir">7. Jumlah Siswa yang tidak hadir <span
                            class="text-danger"><b>*</b></span></label>
                    <input type="text" class="form-control mt-2 <?php $__errorArgs = ['siswa_tidak_hadir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        id="siswa_tidak_hadir" name="siswa_tidak_hadir" autocomplete="off"
                        value="<?php echo e(old('siswa_tidak_hadir')); ?>">
                    <small id="siswa_tidak_hadir" class="form-text text-muted mt-2">Contoh Penulisan :
                        35</small>
                    <?php $__errorArgs = ['siswa_tidak_hadir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group my-4">
                    <label for="deskripsi">8. Deskripsi kegiatan belajar mengajar <span
                            class="text-danger"><b>*</b></span></label>
                    <input type="text" class="form-control mt-2 <?php $__errorArgs = ['deskripsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="deskripsi"
                        name="deskripsi" autocomplete="off" value="<?php echo e(old('deskripsi')); ?>">
                    <?php $__errorArgs = ['deskripsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="d-flex justify-content-end">
                    <button type="submit" class="btn btn-success px-5 mt-2 mb-4">Kirim</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>
<!-- Modal Activity -->
<div class="modal fade" id="modalHistori" data-backdrop="static" data-keyboard="false" tabindex="-1"
    aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="staticBackdropLabel">Histori</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="activities">
                    <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="activity">
                        <div class="activity-icon bg-primary text-white shadow-primary">
                            <i class="fas fa-pen"></i>
                        </div>
                        <div class="activity-detail w-100 mb-2">
                            <div class="mb-1">
                                <span class="text-job text-primary"><?php echo e($activity->journal->tanggal); ?></span>
                                <div class="float-right dropdown">
                                    <span class="font-weight-bold text-primary"><?php echo e($activity->journal->kelas); ?>

                                        <?php echo e($activity->journal->kompetensi_keahlian); ?></span>
                                </div>
                            </div>
                            <p>Mapel: <span
                                    class="font-weight-bold text-primary text-medium"><?php echo e($activity->journal->mata_pelajaran); ?></span>
                                -
                                Jam Ke: <span
                                    class="font-weight-bold text-primary"><?php echo e($activity->journal->jam_ke); ?></span>
                            </p>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\02_Dev\02_Main\journal-app\resources\views/form.blade.php ENDPATH**/ ?>