<table>
  <thead>
    <tr>
      <th><b>NAMA MAPEL</b></th>
    </tr>
  </thead>
</table><?php /**PATH /Applications/MAMP/htdocs/jurnal-gondang/resources/views/admin/mata_pelajaran/format-table.blade.php ENDPATH**/ ?>