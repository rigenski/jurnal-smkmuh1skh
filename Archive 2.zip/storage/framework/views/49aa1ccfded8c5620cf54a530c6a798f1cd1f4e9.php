<table>
    <thead>
        <tr>
            <th scope="col"><b>JAM</b></th>
            <?php $__currentLoopData = $data_kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <th><b><?php echo e($kelas->kelas); ?></b></th>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $data_jam; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <tr>
            <th scopre="row"><b><?php echo e($jam); ?></b></th>

            <?php $__currentLoopData = $data_kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <?php $status = 3; ?>

            

            <?php $__currentLoopData = $data_jurnal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jurnal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <?php if($jurnal->kelas == $kelas->kelas): ?>

            <?php $jam_ke = explode('-', $jurnal->jam_ke);?>

            <?php if(count($jam_ke) == 2): ?>

            <?php $jam_arr = []; ?>

            <?php for($i = $jam_ke[0]; $i <= $jam_ke[1]; $i++): ?> <?php array_push($jam_arr, $i); ?>

                <?php endfor; ?>

                <?php $jam_ke = $jam_arr; ?>

                <?php endif; ?>

                <?php $__currentLoopData = $jam_ke; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jam_ke_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php if($jam_ke_item == $jam): ?>

                <?php $status = 1; ?>

                <?php endif; ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php endif; ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                

                <?php $__currentLoopData = $data_izin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $izin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php if($izin->kelas == $kelas->kelas): ?>

                <?php $jam_ke = explode('-', $izin->jam_ke);?>

                <?php if(count($jam_ke) == 2): ?>

                <?php $jam_arr = []; ?>

                <?php for($i = $jam_ke[0]; $i <= $jam_ke[1]; $i++): ?> <?php array_push($jam_arr, $i); ?>

                    <?php endfor; ?>

                    <?php $jam_ke = $jam_arr; ?>

                    <?php endif; ?>

                    <?php $__currentLoopData = $jam_ke; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jam_ke_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <?php if($jam_ke_item == $jam): ?>

                    <?php $status = 2; ?>

                    <?php endif; ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php endif; ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    

                    <?php if(count($data_pengaturan_izin_guru)): ?>

                    <?php $date = DateTime::createFromFormat('Y-m-d',  $tanggal ? $tanggal : date('Y-m-d')); ?>
                    <?php $hari = $date->format('D') ?>

                    <?php if($hari == 'Mon'): ?>
                    <?php $hari = 'Senin' ?>
                    <?php elseif($hari == 'Tue'): ?>
                    <?php $hari = 'Selasa' ?>
                    <?php elseif($hari == 'Wed'): ?>
                    <?php $hari = 'Rabu' ?>
                    <?php elseif($hari == 'Thu'): ?>
                    <?php $hari = 'Kamis' ?>
                    <?php elseif($hari == 'Fri'): ?>
                    <?php $hari = 'Jumat' ?>
                    <?php endif; ?>

                    <?php $pengaturan_jam = count($data_pengaturan_izin_guru) ? explode('-', $data_pengaturan_izin_guru->where('hari', $hari)->where('kelas', $kelas->kelas)->first()->jam_ke) : [1, 12]; ?>

                    <?php $pengaturan_jam_arr = []; ?>

                    <?php for($i = intval( $pengaturan_jam[0]) - 1; $i <= intval( $pengaturan_jam[1]); $i++): ?> <?php
                        array_push($pengaturan_jam_arr, $i) ?>
                        <?php endfor; ?>

                        <?php if( !array_search( $jam, $pengaturan_jam_arr)): ?>

                        <?php $status = 4 ?>

                        <?php endif; ?>

                        <?php endif; ?>

                        

                        <?php if($status == 1): ?>
                        <td style="background: #47c363;border: 1px solid #fff"></td>
                        <?php elseif($status == 2): ?>
                        <td style="background: #ffa426;border: 1px solid #fff"></td>
                        <?php elseif($status == 3): ?>
                        <td style="background: #fc544b;border: 1px solid #fff"></td>
                        <?php elseif($status == 4): ?>
                        <td style="background: none;border: 1px solid #fff"></td>
                        <?php endif; ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH D:\DEV\main\jurnal-mutuharjo\resources\views/admin/izin_guru/table_kelas.blade.php ENDPATH**/ ?>