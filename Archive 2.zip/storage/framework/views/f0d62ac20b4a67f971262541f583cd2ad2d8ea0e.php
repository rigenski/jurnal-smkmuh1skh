<table>
    <thead>
        <tr>
            <th><b>USERNAME</b></th>
            <th><b>NAMA</b></th>
        </tr>
    </thead>
</table>
<?php /**PATH /Applications/MAMP/htdocs/simaku/jurnal-smkmuh1skh/resources/views/admin/karyawan/format-table.blade.php ENDPATH**/ ?>