<table>
    <thead>
        <tr>
            <th><b>KODE</b></th>
            <th><b>NAMA</b></th>
        </tr>
    </thead>
</table>
<?php /**PATH /Applications/MAMP/htdocs/simaku/jurnal-smkmuh1skh/resources/views/admin/mata_pelajaran/format-table.blade.php ENDPATH**/ ?>