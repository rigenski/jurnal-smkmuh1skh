<table>
    <thead>
        <tr>
            <th><b>KODE</b></th>
            <th><b>NAMA</b></th>
        </tr>
    </thead>
</table>
<?php /**PATH /home/u6418530/public_html/jurnalmu/resources/views/admin/mata_pelajaran/format-table.blade.php ENDPATH**/ ?>