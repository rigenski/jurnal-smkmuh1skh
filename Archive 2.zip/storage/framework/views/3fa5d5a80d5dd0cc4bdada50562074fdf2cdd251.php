

<?php $__env->startSection('main'); ?>
<div class="main-wrapper">
    <div class="navbar-bg"></div>
    <nav class="navbar navbar-expand-lg main-navbar">
        <form class="form-inline mr-auto">
            <ul class="navbar-nav mr-3">
                <li><a href="#" data-toggle="sidebar" class="nav-link nav-link-lg"><i class="fas fa-bars"></i></a></li>
                <li><a href="#" data-toggle="search" class="nav-link nav-link-lg d-sm-none"><i
                            class="fas fa-search"></i></a></li>
            </ul>
        </form>
        <ul class="navbar-nav navbar-right">
            <li class="dropdown"><a href="#" data-toggle="dropdown"
                    class="nav-link dropdown-toggle nav-link-lg nav-link-user">
                    <i class="fas fa-user mr-2"></i>
                    <div class="d-sm-none d-lg-inline-block">Hi, Admin</div>
                </a>
                <div class="dropdown-menu dropdown-menu-right">
                    <a href="<?php echo e(route('logout')); ?>" class="dropdown-item has-icon text-danger">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                </div>
            </li>
        </ul>
    </nav>
    <div class="main-sidebar">
        <aside id="sidebar-wrapper">
            <div class="sidebar-brand">
                <a href=<?php echo e(route('admin')); ?>>Jurnalmu</a>
            </div>
            <ul class="sidebar-menu">
                <li class="menu-header">Dashboard</li>
                <li class="<?php echo $__env->yieldContent('dashboard'); ?>"><a class="nav-link" href="<?php echo e(route('admin')); ?>"><i
                            class="fas fa-home"></i>
                        <span>Dashboard</span></a></li>

                <li class="menu-header">Jurnal</li>
                <li class="<?php echo $__env->yieldContent('jurnal_guru'); ?>"><a class="nav-link" href="<?php echo e(route('admin.jurnal_guru')); ?>">
                        <i class="fas fa-book"></i>
                        <span>Jurnal Guru</span></a></li>
                <li class="<?php echo $__env->yieldContent('jurnal_karyawan'); ?>"><a class="nav-link" href="<?php echo e(route('admin.jurnal_karyawan')); ?>">
                        <i class="fas fa-book"></i>
                        <span>Jurnal Karyawan</span></a></li>
                </li>
                <li class="menu-header">Izin</li>
                <li class="<?php echo $__env->yieldContent('izin_guru'); ?>"><a class="nav-link" href="<?php echo e(route('admin.izin_guru')); ?>">
                        <i class="fas fa-door-open"></i>
                        <span>Izin Guru</span></a></li>
                <li class="menu-header">Tambahan</li>
                <li class="<?php echo $__env->yieldContent('mata_pelajaran'); ?>"><a class="nav-link" href="<?php echo e(route('admin.mata_pelajaran')); ?>"><i
                            class="fas fa-book"></i>
                        <span>Mata Pelajaran</span></a></li>
                <li class="<?php echo $__env->yieldContent('unit_kerja'); ?>"><a class="nav-link" href="<?php echo e(route('admin.unit_kerja')); ?>"><i
                            class="fas fa-cog"></i>
                        <span>Unit Kerja</span></a></li>

                <li class="<?php echo $__env->yieldContent('siswa'); ?>"><a class="nav-link" href="<?php echo e(route('admin.siswa')); ?>"><i
                            class="fas fa-users"></i>
                        <span>Siswa</span></a></li>
                <li class="<?php echo $__env->yieldContent('guru'); ?>"><a class="nav-link" href="<?php echo e(route('admin.guru')); ?>"><i
                            class="fas fa-users"></i>
                        <span>Guru</span></a></li>
                <li class="<?php echo $__env->yieldContent('karyawan'); ?>"><a class="nav-link" href="<?php echo e(route('admin.karyawan')); ?>"><i
                            class="fas fa-users"></i>
                        <span>Karyawan</span></a></li>
            </ul>
        </aside>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <h1><?php echo $__env->yieldContent('title'); ?></h1>
            </div>
            <div class="section-body">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </section>
    </div>
    <footer class="main-footer">
        <div class="footer-left">
            Jurnal - SMK N 1 Gondang Sragen
        </div>
    </footer>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/jurnal-gondang/resources/views/layouts/admin.blade.php ENDPATH**/ ?>