

<?php $__env->startSection('main'); ?>
<div class="main-wrapper">
    <div class="navbar-bg"></div>
    <nav class="navbar navbar-expand-lg main-navbar">
        <form class="form-inline mr-auto">
            <ul class="navbar-nav mr-3">
                <li><a href="#" data-toggle="sidebar" class="nav-link nav-link-lg"><i class="fas fa-bars"></i></a></li>
                <li><a href="#" data-toggle="search" class="nav-link nav-link-lg d-sm-none"><i
                            class="fas fa-search"></i></a></li>
            </ul>
        </form>
        <ul class="navbar-nav navbar-right">
            <li class="dropdown"><a href="#" data-toggle="dropdown"
                    class="nav-link dropdown-toggle nav-link-lg nav-link-user">
                    <i class="fas fa-user mr-2"></i>
                    <div class="d-sm-none d-lg-inline-block">Hi, Admin</div>
                </a>
                <div class="dropdown-menu dropdown-menu-right">
                    <a href="<?php echo e(route('logout')); ?>" class="dropdown-item has-icon text-danger">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                </div>
            </li>
        </ul>
    </nav>
    <div class="main-sidebar">
        <aside id="sidebar-wrapper">
            <div class="sidebar-brand">
                <a href=<?php echo e(route('admin')); ?>>Jurnalmu</a>
            </div>
            <ul class="sidebar-menu">
                <li class="menu-header">Dashboard</li>
                <li class="<?php echo $__env->yieldContent('dashboard'); ?>"><a class="nav-link" href="/admin"><i class="fas fa-home"></i>
                        <span>Dashboard</span></a></li>
                <li class="<?php echo $__env->yieldContent('jurnal'); ?>"><a class="nav-link" href="/admin/jurnal"><i class="fas fa-book"></i>
                        <span>Jurnal</span></a></li>
                <li class="<?php echo $__env->yieldContent('siswa'); ?>"><a class="nav-link" href="/admin/siswa"><i class="fas fa-users-cog"></i>
                        <span>Siswa</span></a></li>
                <li class="<?php echo $__env->yieldContent('guru'); ?>"><a class="nav-link" href="/admin/guru"><i class="fas fa-users"></i>
                        <span>Guru</span></a></li>
            </ul>
        </aside>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <h1><?php echo $__env->yieldContent('title'); ?></h1>
            </div>
            <div class="section-body">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </section>
    </div>
    <footer class="main-footer">
        <div class="footer-left">
            Jurnal Guru - SMK N 1 Gondang Sragen
        </div>
    </footer>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\02_Dev\02_Main\jurnalmu_journal-app\resources\views/layouts/admin.blade.php ENDPATH**/ ?>