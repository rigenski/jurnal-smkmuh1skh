<table>
    <thead>
        <tr>
            <th><b>TANGGAL</b></th>
            <th><b>JAM</b></th>
            <th><b>NAMA</b></th>
            <th><b>KELAS</b></th>
            <th><b>JAM KE</b></th>
            <th><b>MATA PELAJARAN</b></th>
            <th><b>DESKRIPSI</b></th>
            <th><b>SISWA HADIR</b></th>
            <th><b>SISWA TIDAK HADIR</b></th>
            <th><b>PERSENTASE</b></th>
            <th><b>DAFTAR SISWA TIDAK HADIR</b></th>
            <th><b>CATATAN KHUSUS SISWA</b></th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $jurnal_guru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $count = 1; ?>
        <?php $__currentLoopData = $data->siswa_pilihan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswa_pilihan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <?php if($count <= 1): ?> <td><?php echo e($data->tanggal); ?></td>
                <td><?php echo e(date('H:i', strtotime($data->created_at))); ?></td>
                <td><?php echo e($data->nama); ?></td>
                <td><?php echo e($data->kelas); ?></td>
                <td><?php echo e($data->jam_ke); ?></td>
                <td><?php echo e($data->mata_pelajaran); ?></td>
                <td><?php echo e($data->deskripsi); ?></td>
                <td><?php echo e($data->siswa_hadir); ?></td>
                <td><?php echo e($data->siswa_tidak_hadir); ?></td>
                <td>
                    <?php echo e(number_format( ( $siswa->where('kelas', $data->kelas)->count() - $data->siswa_pilihan->count() )
                    / $siswa->where('kelas', $data->kelas)->count() * 100 )); ?>

                    %
                </td>
                <td><?php echo e($siswa_pilihan->nama_siswa); ?></td>
                <td><?php echo e($data->catatan_siswa); ?></td>
                <?php else: ?>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td><?php echo e($siswa_pilihan->nama_siswa); ?></td>
                <td></td>
                <?php endif; ?>
        </tr>
        <?php $count++; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH D:\DEV\main\jurnal-mutuharjo\resources\views/admin/jurnal_guru/table.blade.php ENDPATH**/ ?>