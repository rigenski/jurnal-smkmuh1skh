<table>
    <thead>
        <tr>
            <th><b>USERNAME</b></th>
            <th><b>PASSWORD</b></th>
            <th><b>NIS</b></th>
            <th><b>NAMA</b></th>
            <th><b>KELAS</b></th>
        </tr>
    </thead>
</table>
<?php /**PATH /home/u6418530/public_html/jurnalmu/resources/views/admin/siswa/format-table.blade.php ENDPATH**/ ?>