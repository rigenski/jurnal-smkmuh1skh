<table>
    <thead>
        <tr>
            <th><b>USERNAME</b></th>
            <th><b>PASSWORD</b></th>
            <th><b>NIS</b></th>
            <th><b>NAMA</b></th>
            <th><b>KELAS</b></th>
        </tr>
    </thead>
</table>
<?php /**PATH /Applications/MAMP/htdocs/simaku/jurnal-smkmuh1skh/resources/views/admin/siswa/format-table.blade.php ENDPATH**/ ?>