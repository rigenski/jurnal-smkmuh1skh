<table>
    <thead>
        <tr>
            <th><b>TANGGAL</b></th>
            <th><b>JAM</b></th>
            <th><b>NAMA</b></th>
            <th><b>KELAS</b></th>
            <th><b>JAM KE</b></th>
            <th><b>MATA PELAJARAN</b></th>
            <th><b>DESKRIPSI</b></th>
            <th><b>SISWA HADIR</b></th>
            <th><b>SISWA TIDAK HADIR</b></th>
            <th><b>PERSENTASE</b></th>
            <th><b>DAFTAR SISWA TIDAK HADIR</b></th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $journal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $count = 1; ?>
        <?php $__currentLoopData = $journal->choice; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $choice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <?php if($count <= 1): ?> <td><?php echo e($journal->tanggal); ?></td>
                <td><?php echo e(date('H:i', strtotime($journal->created_at))); ?></td>
                <td><?php echo e($journal->nama); ?></td>
                <td><?php echo e($journal->kelas); ?></td>
                <td><?php echo e($journal->jam_ke); ?></td>
                <td><?php echo e($journal->mata_pelajaran); ?></td>
                <td><?php echo e($journal->deskripsi); ?></td>
                <td><?php echo e($journal->siswa_hadir); ?></td>
                <td><?php echo e($journal->siswa_tidak_hadir); ?></td>
                <td>
                    <?php echo e(number_format( ( $students->where('kelas', $journal->kelas)->count() - $journal->choice->count() ) / $students->where('kelas', $journal->kelas)->count() * 100 )); ?>

                    %
                </td>
                <td><?php echo e($choice->nama_siswa); ?></td>
                <?php else: ?>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td><?php echo e($choice->nama_siswa); ?></td>
                <?php endif; ?>
        </tr>
        <?php $count++; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH D:\02_Dev\02_Main\jurnalmu_journal-app\resources\views/admin/table.blade.php ENDPATH**/ ?>