<table>
  <thead>
    <tr>
      <th><b>NAMA MAPEL</b></th>
    </tr>
  </thead>
</table><?php /**PATH D:\DEV\main\jurnal-mutuharjo\resources\views/admin/mata_pelajaran/format-table.blade.php ENDPATH**/ ?>