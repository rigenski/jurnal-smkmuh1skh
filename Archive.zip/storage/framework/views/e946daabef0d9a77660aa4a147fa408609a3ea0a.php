<table>
    <thead>
        <tr>
            <th><b>TANGGAL</b></th>
            <th><b>JAM</b></th>
            <th><b>NAMA</b></th>
            <th><b>UNIT KERJA</b></th>
            <th><b>DESKRIPSI</b></th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $jurnal_karyawan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>

            <td><?php echo e($data->tanggal); ?></td>
            <td><?php echo e(date('H:i', strtotime($data->created_at))); ?></td>
            <td><?php echo e($data->nama); ?></td>
            <td><?php echo e($data->unit_kerja); ?></td>
            <td><?php echo e($data->deskripsi); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH D:\DEV\main\jurnal-mutuharjo\resources\views/admin/jurnal_karyawan/table.blade.php ENDPATH**/ ?>