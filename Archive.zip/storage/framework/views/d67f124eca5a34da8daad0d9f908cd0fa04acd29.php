<table>
    <thead>
        <tr>
            <th><b>NIS</b></th>
            <th><b>NAMA</b></th>
            <th><b>KELAS</b></th>
            <th><b>KEAHLIAN</b></th>
            <th><b>PENUGASAN</b></th>
            <th><b>PREDIKAT</b></th>
            <th><b>KOMPETENSI</b></th>
        </tr>
    </thead>
</table>
<?php /**PATH /Applications/MAMP/htdocs/simaku/jurnal-smkmuh1skh/resources/views/admin/sertifikat/format-table.blade.php ENDPATH**/ ?>