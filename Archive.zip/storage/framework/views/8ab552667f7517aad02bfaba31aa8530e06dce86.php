<table>
    <thead>
        <tr>
            <th><b>BULAN</b></th>
            <th><b>NAMA</b></th>
            <th><b>KELAS</b></th>
            <th><b>MATA PELAJARAN</b></th>
            <th><b>P1</b></th>
            <th><b>P2</b></th>
            <th><b>P3</b></th>
            <th><b>P4</b></th>
            <th><b>P5</b></th>
            <th><b>P6</b></th>
            <th><b>P7</b></th>
            <th><b>P8</b></th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $data_refleksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $count = 1; ?>
            <tr>
                <td><?php echo e($data->bulan); ?></td>
                <td><?php echo e($data->nama); ?></td>
                <td><?php echo e($data->kelas); ?></td>
                <td><?php echo e($data->mata_pelajaran); ?></td>
                <td><?php echo e($data->pertanyaan1); ?></td>
                <td><?php echo e($data->pertanyaan2); ?></td>
                <td><?php echo e($data->pertanyaan3); ?></td>
                <td><?php echo e($data->pertanyaan4); ?></td>
                <td><?php echo e($data->pertanyaan5); ?></td>
                <td><?php echo e($data->pertanyaan6); ?></td>
                <td><?php echo e($data->pertanyaan7); ?></td>
                <td><?php echo e($data->pertanyaan8); ?></td>
            </tr>
        <?php $count++; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<table>
    <tbody>
        <tr>
            <td></td>
        </tr>
    </tbody>
</table>
<table>
    <tbody>
        <tr>
            <td colspan="16">INFORMASI</td>
        </tr>
        <tr>
            <td colspan="16">P1: Apa yang berjalan baik bulan ini</td>
        </tr>
        <tr>
            <td colspan="16">P2: Apa yang tidak berjalan baik bulan ini</td>
        </tr>
        <tr>
            <td colspan="16">P3: Keterampilan apa yang dikuasai oleh siswa dibulan ini</td>
        </tr>
        <tr>
            <td colspan="16">P4: Keterampilan apa yang masih perlu ditingkatkan oleh siswa</td>
        </tr>
        <tr>
            <td colspan="16">P5: Jika memiliki kesempatan mengajar materi pelajaran yang sama pada kelompok siswa yang sama, hal apa yang akan dilakukan secara berbeda</td>
        </tr>
        <tr>
            <td colspan="16">P6: Sebutkan nama siswa yang terlibat aktif dalam pembelajaran bulan ini</td>
        </tr>
        <tr>
            <td colspan="16">P7: Sebutkan nama siswa yang tampak membutuhkan lebih banyak dukungan dan perhatian dibulan berikutnya</td>
        </tr>
        <tr>
            <td colspan="16">P8: Hal apa yang perlu diperbaiki kedepan agar sekolah ini tetap Unggul</td>
        </tr>
    </tbody>
</table><?php /**PATH /Applications/MAMP/htdocs/jurnal-mutuharjo/resources/views/admin/refleksi_guru/table.blade.php ENDPATH**/ ?>