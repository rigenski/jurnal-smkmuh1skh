

<?php $__env->startSection('main'); ?>
<div class="d-flex justify-content-center align-items-center" style="height: 100vh;">
    <div class="empty-state" data-height="400" style="height: 400px;">
        <?php if(session('success')): ?>
        <lottie-player src="https://assets1.lottiefiles.com/packages/lf20_qlmzlzeq.json" background="transparent"
            speed="1" style="width: 300px; height: 300px;" loop autoplay></lottie-player>
        <h2 class="text-success">Terima Kasih ✨</h2>
        <p class="lead">
            Selamat <span class="font-weight-bold text-primary"><?php echo e(auth()->user()->name); ?></span> , data <?php echo e(session('success') == 'jurnal' ? 'jurnal' : ( session('success') == 'izin' ? 'izin' : null )); ?> yang
            anda kirim telah berhasil dikirim
        </p>
        <?php else: ?>
        <lottie-player src="https://assets1.lottiefiles.com/packages/lf20_d4y2uivj.json" background="transparent"
            speed="1" style="width: 300px; height: 300px;" loop autoplay></lottie-player>
        <h2 class="text-danger">Silahkan Kembali 📑</h2>
        <p class="lead">
            Maaf <span class="font-weight-bold text-primary"><?php echo e(auth()->user()->name); ?></span> , mohon isi formulir
            data jurnal / izin terlebih dahulu
        </p>
        <?php endif; ?>
        <a href="<?php echo e(route('home')); ?>" class="btn btn-success mt-4">Kembali</a>
        <a href="<?php echo e(route('logout')); ?>" class="mt-4 font-weight-bold border-bottom border-danger text-danger">Logout</a>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DEV\main\jurnal-mutuharjo\resources\views/congrats.blade.php ENDPATH**/ ?>