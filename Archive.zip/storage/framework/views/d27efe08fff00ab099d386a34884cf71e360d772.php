<table>
    <thead>
        <tr>
            <th><b>TANGGAL</b></th>
            <th><b>JAM</b></th>
            <th><b>NAMA</b></th>
            <th><b>KELAS</b></th>
            <th><b>JAM KE</b></th>
            <th><b>RUANG</b></th>
            <th><b>JENIS IZIN</b></th>
            <th><b>PETUNJUK TUGAS</b></th>
            <th><b>PETUNJUK TUGAS FILE</b></th>
            <th><b>SURAT IZIN</b></th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $data_izin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($data->tanggal); ?></td>
            <td><?php echo e(date('H:i', strtotime($data->created_at))); ?></td>
            <td><?php echo e($data->nama); ?></td>
            <td><?php echo e($data->kelas); ?></td>
            <td><?php echo e($data->jam_ke); ?></td>
            <td><?php echo e($data->ruang); ?></td>
            <td><?php echo e($data->jenis_izin); ?></td>
            <td><?php echo e($data->petunjuk_tugas); ?></td>
            <td><?php echo e($data->petunjuk_tugas_file ? asset('/dokumen/petunjuk_tugas_file/' . $data->petunjuk_tugas_file ) :
                null); ?></td>
            <td><?php echo e($data->surat_izin ? asset('/dokumen/surat_izin/' . $data->surat_izin ) : null); ?></td>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH D:\DEV\main\jurnal-mutuharjo\resources\views/admin/izin_guru/table_guru.blade.php ENDPATH**/ ?>