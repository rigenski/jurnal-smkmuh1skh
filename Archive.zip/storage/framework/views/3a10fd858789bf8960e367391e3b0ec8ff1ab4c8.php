<table>
  <thead>
    <tr>
      <th><b>NIS</b></th>
      <th><b>NAMA</b></th>
      <th><b>KELAS</b></th>
    </tr>
  </thead>
</table><?php /**PATH /Applications/MAMP/htdocs/jurnal-gondang/resources/views/admin/siswa/format-table.blade.php ENDPATH**/ ?>