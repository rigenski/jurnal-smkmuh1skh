<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Jurnal Guru Mutuharjo</title>

    <link rel="stylesheet" href="<?php echo e(asset('/assets/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/assets/css/all.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/assets/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/assets/css/components.css')); ?>">
</head>

<body class="">
    <div id="app">
        <?php echo $__env->yieldContent('main'); ?>
    </div>

    <script src="<?php echo e(asset('/assets/js/jquery-3.3.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/js/popper.min.js')); ?>">
    </script>
    <script src="<?php echo e(asset('/assets/js/bootstrap.min.js')); ?>">
    </script>
    <script src="<?php echo e(asset('/assets/js/jquery.nicescroll.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/js/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/js/stisla.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/js/scripts.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/js/custom.js')); ?>"></script>
</body>

</html><?php /**PATH D:\02_Dev\02_Main\journal-app\resources\views/layouts/main.blade.php ENDPATH**/ ?>