<?php $__env->startSection('refleksi_siswa', 'active'); ?>

<?php $__env->startSection('title', 'Refleksi Siswa'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <div class="row w-100 mx-0">
                <div class="col-12 col-md-6 px-0">
                    <div class="d-flex justify-content-start align-items-center flex-wrap">
                        <button type="button" class="btn btn-primary mr-2 mb-2" data-toggle="modal"
                            data-target="#modal-filter">
                            Filter
                        </button>
                        <form action="<?php echo e(route('admin.refleksi_siswa')); ?>" method="get" class="d-flex">
                            <input type="hidden" name="tahun_pelajaran" value=<?php echo e($request->tahun_pelajaran); ?>>
                            <input type="hidden" name="semester" value=<?php echo e($request->semester); ?>>
                            <select class="form-control py-0 mr-2 mb-2" autocomplete="off" name="kelas"
                                style="width: 160px;height: 32px;">
                                <?php $__currentLoopData = $data_kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($request->kelas == $kelas): ?>
                                        <option value="<?php echo e($kelas); ?>" selected><?php echo e($kelas); ?></option>
                                    <?php else: ?>
                                        <option value="<?php echo e($kelas); ?>"><?php echo e($kelas); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <button type="submit" class="btn btn-primary mr-2 mb-2">Cari</button>
                        </form>
                    </div>
                </div>
                <div class="col-12 col-md-6 px-0">
                    <div class="d-flex justify-content-end align-items-center flex-wrap">
                        <div class="d-flex">
                            <a href="<?php echo e(route('admin.refleksi_siswa')); ?>" class="btn btn-warning px-2 ml-2 mb-2">
                                <svg xmlns="http://www.w3.org/2000/svg" height="28" fill="currentColor"
                                    class="bi bi-arrow-repeat m-auto text-white" viewBox="0 0 16 16">
                                    <path
                                        d="M11.534 7h3.932a.25.25 0 0 1 .192.41l-1.966 2.36a.25.25 0 0 1-.384 0l-1.966-2.36a.25.25 0 0 1 .192-.41zm-11 2h3.932a.25.25 0 0 0 .192-.41L2.692 6.23a.25.25 0 0 0-.384 0L.342 8.59A.25.25 0 0 0 .534 9z" />
                                    <path fill-rule="evenodd"
                                        d="M8 3c-1.552 0-2.94.707-3.857 1.818a.5.5 0 1 1-.771-.636A6.002 6.002 0 0 1 13.917 7H12.9A5.002 5.002 0 0 0 8 3zM3.1 9a5.002 5.002 0 0 0 8.757 2.182.5.5 0 1 1 .771.636A6.002 6.002 0 0 1 2.083 9H3.1z" />
                                </svg>
                            </a>
                            <?php if($request->tahun_pelajaran != null && $request->semester != null && $request->kelas != null): ?>
                                <a href="<?php echo e(route('admin.refleksi_siswa.export')); ?>"
                                    class="btn btn-success ml-2 mb-2">Export</a>
                            <?php else: ?>
                                <a href="/" class="btn btn-success ml-2 mb-2 disabled">Export</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped table-bordered data">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">NIS</th>
                            <th scope="col">Nama</th>
                            <th scope="col">Kelas</th>
                            <th scope="col">Guru</th>
                            <th scope="col">Mata Pelajaran</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $count = 1; ?>
                        <?php $__currentLoopData = $data_refleksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($count); ?></th>
                                <td><?php echo e($data->nis); ?></td>
                                <td><?php echo e($data->nama); ?></td>
                                <td><?php echo e($data->kelas); ?></td>
                                <td><?php echo e($data->guru); ?></td>
                                <td><?php echo e($data->mata_pelajaran); ?></td>
                            </tr>
                            <?php $count++; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>

    <!-- Modal Filter -->
    <div class="modal fade" id="modal-filter" data-backdrop="static" data-keyboard="false" tabindex="-1"
        aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog">
            <form class="modal-content" action="<?php echo e(route('admin.refleksi_siswa')); ?>" method="get">
                <div class="modal-header">
                    <h5 class="modal-title" id="staticBackdropLabel">Filter Data <span class="text-primary">Nilai</span>
                    </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label for="tahun_pelajaran">Tahun Pelajaran</label>
                        <select class="form-control" autocomplete="off" id="tahun_pelajaran" name="tahun_pelajaran">
                            <?php $__currentLoopData = $data_tahun_pelajaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tahun_pelajaran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($request->tahun_pelajaran == $tahun_pelajaran): ?>
                                    <option value="<?php echo e($tahun_pelajaran); ?>" selected><?php echo e($tahun_pelajaran); ?></option>
                                <?php else: ?>
                                    <option value="<?php echo e($tahun_pelajaran); ?>"><?php echo e($tahun_pelajaran); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="semester">Semester</label>
                        <select class="form-control" autocomplete="off" name="semester">
                            <?php $__currentLoopData = $data_semester; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $semester): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($request->semester == $semester): ?>
                                    <option value="<?php echo e($semester); ?>" selected><?php echo e($semester); ?></option>
                                <?php else: ?>
                                    <option value="<?php echo e($semester); ?>"><?php echo e($semester); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary mr-2" data-dismiss="modal">Kembali</button>
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/simaku/jurnal-smkmuh1skh/resources/views/admin/refleksi_siswa/index.blade.php ENDPATH**/ ?>