<table>
    <thead>
        <tr>
            <th><b>KELAS</b></th>
            <th><b>KODE MATA PELAJARAN</b></th>
            <th><b>NAMA MATA PELAJARAN</b></th>
            <th><b>USERNAME GURU</b></th>
            <th><b>NAMA GURU</b></th>
        </tr>
    </thead>
</table>
<?php /**PATH /Applications/MAMP/htdocs/simaku/jurnal-smkmuh1skh/resources/views/admin/guru_mata_pelajaran/format-table.blade.php ENDPATH**/ ?>