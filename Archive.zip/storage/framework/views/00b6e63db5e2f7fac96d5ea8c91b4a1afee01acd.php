<table>
    <thead>
        <tr>
            <th scope="col">JAM</th>
            <?php $__currentLoopData = $data_kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <th><?php echo e($kelas->kelas); ?></th>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $data_jam; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <tr>
            <th scopre="row"><?php echo e($jam); ?></th>

            <?php $__currentLoopData = $data_kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <?php $status = true; ?>

            <?php $__currentLoopData = $data_izin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $izin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <?php if($izin->kelas == $kelas->kelas): ?>

            <?php $jam_ke = explode('-', $izin->jam_ke);?>

            <?php if(count($jam_ke) == 2): ?>

            <?php $jam_arr = []; ?>

            <?php for($i = $jam_ke[0]; $i <= $jam_ke[1]; $i++): ?> <?php array_push($jam_arr, $i); ?>

                <?php endfor; ?>

                <?php $jam_ke = $jam_arr; ?>

                <?php endif; ?>

                <?php $__currentLoopData = $jam_ke; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jam_ke_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php if($jam_ke_item == $jam): ?>

                <?php $status = false; ?>

                <?php endif; ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php endif; ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php if($status): ?>
                <td style="background: #47c363;border: 1px solid #fff"></td>
                <?php else: ?>
                <td style="background: #fc544b;border: 1px solid #fff"></td>
                <?php endif; ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH D:\DEV\main\jurnal-mutuharjo\resources\views/admin/izin_guru/table.blade.php ENDPATH**/ ?>