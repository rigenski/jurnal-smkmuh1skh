<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PengaturanIzinGuru extends Model
{
    protected $table = 'pengaturan_izin_guru';
    protected $guarded = [];
}
