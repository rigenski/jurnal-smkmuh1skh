<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class IzinGuru extends Model
{
    protected $table = 'izin_guru';
    protected $guarded = [];
}
