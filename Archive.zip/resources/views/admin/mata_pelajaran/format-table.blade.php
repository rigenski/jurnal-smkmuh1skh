<table>
    <thead>
        <tr>
            <th><b>KODE</b></th>
            <th><b>NAMA</b></th>
        </tr>
    </thead>
</table>
