<table>
  <thead>
    <tr>
      <th><b>NAMA</b></th>
    </tr>
  </thead>
</table>