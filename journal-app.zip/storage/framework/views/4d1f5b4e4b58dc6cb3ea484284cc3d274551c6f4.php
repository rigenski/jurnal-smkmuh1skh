

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<ol class="breadcrumb mb-4">
    <li class="breadcrumb-item active">Dashboard</li>
</ol>
<div class="row">
    <div class="col-md-6 ">
        <div class="card bg-primary text-white mb-4">
            <div class="card-body"><?php echo e(count($total_journal)); ?></div>
            <div class="card-footer d-flex align-items-center justify-content-between">
                <h5 class="small text-white" >Total Data</h5>
            </div>
        </div>
    </div>
    <div class="col-md-6 ">
        <div class="card bg-success text-white mb-4">
            <div class="card-body">0</div>
            <div class="card-footer d-flex align-items-center justify-content-between">
                <h5 class="small text-white">Total Guru</h5>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-xl-6">
        <div class="card mb-4">
            <div class="card-header">
                <i class="fas fa-chart-area mr-1"></i>
                Cart per Minggu
            </div>
            <div class="card-body"><canvas id="myAreaChart" width="100%" height="40"></canvas></div>
        </div>
    </div>
    <div class="col-xl-6">
        <div class="card mb-4">
            <div class="card-header">
                <i class="fas fa-chart-bar mr-1"></i>
                Bar Chart Example
            </div>
            <div class="card-body"><canvas id="myBarChart" width="100%" height="40"></canvas></div>
        </div>
    </div>
</div>
<div class="card mb-4">
    <div class="card-header">
        <div class="row">
            <div class="col-md-12">
                <div class="d-flex align-items-center flex-column bd-highlight ">
                    <h5>Last Data</h5>
                </div>
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th scope="col">Tanggal</th>
                        <th scope="col">Jam</th>
                        <th scope="col">Nama</th>
                        <th scope="col">Kelas</th>
                        <th scope="col">Jurusan</th>
                        <th scope="col">Jam Ke</th>
                        <th scope="col">Mata Pelajaran</th>
                        <th scope="col">Siswa Hadir</th>
                        <th scope="col">Siswa Tidak Hadir</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data_journal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $journal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($journal->tanggal); ?></td>
                        <td><?php echo e(date('H:i', strtotime($journal->created_at))); ?></td>
                        <td><?php echo e($journal->nama); ?></td>
                        <td><?php echo e($journal->kelas); ?></td>
                        <td><?php echo e($journal->kompetensi_keahlian); ?></td>
                        <td><?php echo e($journal->jam_ke); ?></td>
                        <td><?php echo e($journal->mata_pelajaran); ?></td>
                        <td><?php echo e($journal->siswa_hadir); ?></td>
                        <td><?php echo e($journal->siswa_tidak_hadir); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\02_DEV\01_WEB\02_PROJECT\jurnal-app\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>