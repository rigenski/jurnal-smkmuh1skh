<table>
    <thead>
    <tr>
        <th><b>TANGGAL</b></th>
        <th><b>JAM</b></th>
        <th><b>NAMA</b></th>
        <th><b>KELAS</b></th>
        <th><b>KOMPETENSI KEAHLIAN</b></th>
        <th><b>JAM KE</b></th>
        <th><b>MATA PELAJARAN</b></th>
        <th><b>SISWA HADIR</b></th>
        <th><b>SISWA TIDAK HADIR</b></th>
        <th><b>DESKRIPSI</b></th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $journal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($journal->tanggal); ?></td>
            <td><?php echo e(date('H:i:s', strtotime($journal->created_at))); ?></td>
            <td><?php echo e($journal->nama); ?></td>
            <td><?php echo e($journal->kelas); ?></td>
            <td><?php echo e($journal->kompetensi_keahlian); ?></td>
            <td><?php echo e($journal->jam_ke); ?></td>
            <td><?php echo e($journal->mata_pelajaran); ?></td>
            <td><?php echo e($journal->siswa_hadir); ?></td>
            <td><?php echo e($journal->siswa_tidak_hadir); ?></td>
            <td><?php echo e($journal->deskripsi); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH D:\02_DEV\01_WEB\01_MAIN\journal-app\resources\views/admin/table.blade.php ENDPATH**/ ?>